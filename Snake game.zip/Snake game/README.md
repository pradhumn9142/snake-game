# Snake-JavaScript

The Snake game, created using JavaScript, and The HTML5 canvas.

Download the starter template, and follow the tutorial on youtube step by step.

Tutorial link : https://youtu.be/9TcU2C1AACw
